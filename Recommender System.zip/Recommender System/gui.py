import tkinter as tk
from tkinter import messagebox
from recommender import recommend_movies  # Import the recommend_movies function from recommender.py

def on_recommend():
    movie_title = entry.get()
    try:
        recommendations = recommend_movies(movie_title)
        messagebox.showinfo("Recommendations", "\n".join(recommendations))
    except Exception as e:
        messagebox.showerror("Error", str(e))

# Tkinter GUI setup
root = tk.Tk()
root.title("Movie Recommender System")

label = tk.Label(root, text="Enter a movie title:")
label.pack()

entry = tk.Entry(root)
entry.pack()

recommend_button = tk.Button(root, text="Recommend", command=on_recommend)
recommend_button.pack()

root.mainloop()
