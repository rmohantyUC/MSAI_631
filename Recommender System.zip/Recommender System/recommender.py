# Load dataset
path='/Users/reemmohanty/Documents/UCumberlands M.S AI in Business/MSAI 631 (AI for Human Computer Interaction)/Week 6/Recommender System/imdb_sampled.csv'

# recommender.py

import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.preprocessing import MinMaxScaler
import numpy as np

# Load dataset
df = pd.read_csv(path)

# Preprocess genres for TF-IDF vectorization
df['genres'] = df['genres'].fillna('')  # Handle missing values
df['genres'] = df['genres'].apply(lambda x: ' '.join(x.replace(',', ' ').split()))

# TF-IDF vectorization of genres
tfidf_vect = TfidfVectorizer(stop_words='english')
tfidf_matrix = tfidf_vect.fit_transform(df['genres'])

# Normalize continuous features (averageRating and numVotes)
scaler = MinMaxScaler()
df['normalizedRating'] = scaler.fit_transform(df[['averageRating']])
df['normalizedVotes'] = scaler.fit_transform(df[['numVotes']])

# Combine feature vectors
feature_matrix = np.hstack((tfidf_matrix.toarray(), df[['normalizedRating', 'normalizedVotes']].values))

# Compute cosine similarity
cosine_sim = cosine_similarity(feature_matrix, feature_matrix)

# Function to get movie title from movie index
def get_title_from_index(index):
    return df.iloc[index]['sortedTitle']

# Function to get movie index from movie title
def get_index_from_title(title):
    indices = df[df['sortedTitle'].str.lower() == title.lower()].index
    if len(indices) > 0:
        return indices[0]
    else:
        raise ValueError(f"No movie found with the title '{title}'. Please check the title and try again.")


# Function that takes a movie title as input and outputs a list of similar movies
def recommend_movies(movie_title):
    try:
        movie_index = get_index_from_title(movie_title)
        similar_movies = list(enumerate(cosine_sim[movie_index]))
        sorted_similar_movies = sorted(similar_movies, key=lambda x: x[1], reverse=True)[1:]

        recommendations = [get_title_from_index(index) for i, (index, sim) in enumerate(sorted_similar_movies) if i < 5]
        return recommendations
    except ValueError as e:
        raise ValueError(str(e))
