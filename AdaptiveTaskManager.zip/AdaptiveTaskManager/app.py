from flask import Flask, render_template, request, redirect, url_for
import sqlite3
import os

app = Flask(__name__)
DATABASE = 'tasks.db'

def get_db_connection():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db_connection()
    cursor = conn.cursor()

    # Check if the database and the 'tasks' table already exist
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='tasks'")
    table_exists = cursor.fetchone()

    if table_exists:
        # The 'tasks' table exists, check if 'frequency' column exists
        cursor.execute("PRAGMA table_info(tasks)")
        columns = [info[1] for info in cursor.fetchall()]
        if "frequency" not in columns:
            cursor.execute('ALTER TABLE tasks ADD COLUMN frequency INTEGER DEFAULT 0')
    else:
        # The 'tasks' table does not exist, create it
        cursor.execute('''
            CREATE TABLE tasks (
                id INTEGER PRIMARY KEY,
                description TEXT,
                completed BOOLEAN,
                frequency INTEGER DEFAULT 0
            )''')

    conn.commit()
    cursor.close()
    conn.close()


@app.route('/')
def index():
    conn = get_db_connection()
    tasks = conn.execute('SELECT * FROM tasks ORDER BY frequency DESC, id DESC').fetchall()
    
    # Get the top 3 most frequent uncompleted tasks for suggestions
    suggestions = conn.execute('''
        SELECT description FROM tasks 
        WHERE completed = 0 
        GROUP BY description 
        ORDER BY SUM(frequency) DESC 
        LIMIT 3
    ''').fetchall()
    
    conn.close()
    return render_template('index.html', tasks=tasks, suggestions=suggestions)

@app.route('/add', methods=['POST'])
def add():
    description = request.form['description']
    if description:
        conn = get_db_connection()
        # Check if task already exists (case-insensitive)
        existing_task = conn.execute('SELECT id FROM tasks WHERE LOWER(description) = LOWER(?)', (description,)).fetchone()
        if existing_task:
            conn.execute('UPDATE tasks SET frequency = frequency + 1 WHERE id = ?', (existing_task['id'],))
        else:
            conn.execute('INSERT INTO tasks (description, completed) VALUES (?, ?)', (description, False))
        conn.commit()
        conn.close()
    return redirect(url_for('index'))

@app.route('/delete/<int:task_id>')
def delete(task_id):
    conn = get_db_connection()
    conn.execute('DELETE FROM tasks WHERE id = ?', (task_id,))
    conn.commit()
    conn.close()
    return redirect(url_for('index'))

@app.route('/complete/<int:task_id>')
def complete(task_id):
    conn = get_db_connection()
    conn.execute('UPDATE tasks SET completed = True, frequency = frequency + 1 WHERE id = ?', (task_id,))
    conn.commit()
    conn.close()
    return redirect(url_for('index'))

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
