from botbuilder.core import ActivityHandler, TurnContext, ConversationState, UserState
from botbuilder.dialogs import DialogSet, WaterfallDialog, WaterfallStepContext, DialogTurnResult, Dialog
from botbuilder.dialogs import Dialog


from botbuilder.core import ActivityHandler, TurnContext, ConversationState
from botbuilder.dialogs import DialogSet, DialogTurnStatus
from helpers.dialog_helper import DialogHelper

class DialogBot(ActivityHandler):
    def __init__(self, conversation_state: ConversationState, dialog: Dialog):
        if conversation_state is None:
            raise Exception("[DialogBot]: Missing parameter. conversation_state is required")
        if dialog is None:
            raise Exception("[DialogBot]: Missing parameter. dialog is required")

        self.conversation_state = conversation_state
        self.dialog = dialog
        self.dialogs = DialogSet(conversation_state.create_property("DialogState"))

    async def on_turn(self, turn_context: TurnContext):
        dialog_context = await self.dialogs.create_context(turn_context)

        if dialog_context.active_dialog is not None:
            await dialog_context.continue_dialog()
        else:
            await dialog_context.begin_dialog(self.dialog.id)

        await self.conversation_state.save_changes(turn_context)

    async def on_message_activity(self, turn_context: TurnContext):
        dialog_context = await self.dialogs.create_context(turn_context)

        results = await dialog_context.continue_dialog()
        if results.status == DialogTurnStatus.Empty:
            await dialog_context.begin_dialog(self.dialog.id)

        await self.conversation_state.save_changes(turn_context)

    async def on_members_added_activity(self, members_added, turn_context: TurnContext):
        for member in members_added:
            if member.id != turn_context.activity.recipient.id:
                await turn_context.send_activity("Welcome to our E-commerce bot!")
                await self.on_message_activity(turn_context)
