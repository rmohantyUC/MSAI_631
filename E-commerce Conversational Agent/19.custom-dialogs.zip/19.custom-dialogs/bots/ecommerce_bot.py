from botbuilder.core import ActivityHandler, MessageFactory, TurnContext
from botbuilder.dialogs import DialogSet, WaterfallDialog, WaterfallStepContext, DialogTurnResult
from botbuilder.dialogs.prompts import ChoicePrompt, PromptOptions, TextPrompt
from botbuilder.core import ConversationState, UserState
from botbuilder.dialogs.choices import Choice
from botbuilder.dialogs import Dialog



class EcommerceBot(ActivityHandler):
    def __init__(self, conversation_state: ConversationState, user_state: UserState, sneaker_dialog: Dialog):
        self.conversation_state = conversation_state
        self.user_state = user_state
        self.sneaker_dialog = sneaker_dialog

        self.dialogs = DialogSet(self.conversation_state.create_property("DialogState"))
        self.dialogs.add(ChoicePrompt("ChoicePrompt"))
        self.dialogs.add(TextPrompt("TextPrompt"))

        self.dialogs.add(WaterfallDialog("mainDialog", [
            self.prompt_for_category,
            self.handle_category_selection,
            self.prompt_for_size,
            self.add_to_cart_confirmation,
            self.checkout_confirmation,
        ]))

    async def on_turn(self, turn_context: TurnContext):
        dialog_context = await self.dialogs.create_context(turn_context)

        if dialog_context.active_dialog is not None:
            await dialog_context.continue_dialog()
        else:
            await dialog_context.begin_dialog("mainDialog")

        await self.conversation_state.save_changes(turn_context)

    async def prompt_for_category(self, step: WaterfallStepContext) -> DialogTurnResult:
        return await step.prompt(
            "ChoicePrompt",
            PromptOptions(
                prompt=MessageFactory.text("Which category of sneakers are you interested in?"),
                choices=[Choice("Running"), Choice("Casual"), Choice("Basketball")]
            )
        )

    async def handle_category_selection(self, step: WaterfallStepContext) -> DialogTurnResult:
        category = step.result.value
        step.values["category"] = category
        await step.context.send_activity(MessageFactory.text(f"Great! Here are some {category} sneakers."))
        # Simulate showing products
        return await step.prompt("TextPrompt", PromptOptions(prompt=MessageFactory.text(f"Type the name of the sneaker you're interested in.")))

    async def prompt_for_size(self, step: WaterfallStepContext) -> DialogTurnResult:
        sneaker_name = step.result
        step.values["sneaker_name"] = sneaker_name
        # Simulate product details
        await step.context.send_activity(MessageFactory.text(f"Here are the details for {sneaker_name}."))
        return await step.prompt("TextPrompt", PromptOptions(prompt=MessageFactory.text("What size do you need?")))

    async def add_to_cart_confirmation(self, step: WaterfallStepContext) -> DialogTurnResult:
        size = step.result
        step.values["size"] = size
        # Confirm add to cart
        await step.context.send_activity(MessageFactory.text(f"Added {step.values['sneaker_name']} Size {size} to the cart."))
        return await step.prompt("ChoicePrompt", PromptOptions(prompt=MessageFactory.text("Would you like to checkout or continue browsing?"), choices=[Choice("Checkout"), Choice("Continue Browsing")]))

    async def checkout_confirmation(self, step: WaterfallStepContext) -> DialogTurnResult:
        if step.result.value == "Checkout":
            # Process checkout
            await step.context.send_activity(MessageFactory.text("Proceeding to checkout."))
        else:
            # Continue browsing
            return await step.replace_dialog("mainDialog")
        return DialogTurnResult(DialogTurnStatus.Complete)
