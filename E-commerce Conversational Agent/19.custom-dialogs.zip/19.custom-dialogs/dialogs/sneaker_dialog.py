from botbuilder.dialogs import ComponentDialog, WaterfallDialog, WaterfallStepContext
from botbuilder.dialogs.prompts import TextPrompt, ChoicePrompt, PromptOptions
from botbuilder.core import MessageFactory
from botbuilder.dialogs.choices import Choice

class SneakerDialog(ComponentDialog):
    def __init__(self, dialog_id: str = "SneakerDialog"):
        super(SneakerDialog, self).__init__(dialog_id)

        self.add_dialog(TextPrompt("TextPrompt"))
        self.add_dialog(ChoicePrompt("ChoicePrompt"))

        self.add_dialog(WaterfallDialog("WFDialog", [
            self.prompt_for_category,
            self.show_products,
            self.prompt_for_action,
            self.process_action
        ]))

        self.initial_dialog_id = "WFDialog"

    async def prompt_for_category(self, step: WaterfallStepContext):
        return await step.prompt(
            "ChoicePrompt",
            PromptOptions(
                prompt=MessageFactory.text("Please select a sneaker category you're interested in:"),
                choices=[Choice("Running"), Choice("Casual"), Choice("Basketball")]
            )
        )

    async def show_products(self, step: WaterfallStepContext):
        category = step.result.value
        step.values["category"] = category
        # Simulate fetching and showing products from the selected category
        await step.context.send_activity(MessageFactory.text(f"Showing {category} sneakers..."))
        return await step.prompt("TextPrompt", PromptOptions(prompt=MessageFactory.text("Type the name of the product for more details, or type 'Browse' to see more products.")))

    async def prompt_for_action(self, step: WaterfallStepContext):
        product_name = step.result
        step.values["product_name"] = product_name
        # Simulate showing product details
        await step.context.send_activity(MessageFactory.text(f"Details for {product_name}. Do you want to add to cart or continue browsing?"))
        return await step.prompt(
            "ChoicePrompt",
            PromptOptions(
                prompt=MessageFactory.text("Choose an option:"),
                choices=[Choice("Add to Cart"), Choice("Continue Browsing")]
            )
        )

    async def process_action(self, step: WaterfallStepContext):
        action = step.result.value
        if action == "Add to Cart":
            # Process adding the selected product to the cart
            await step.context.send_activity(MessageFactory.text(f"{step.values['product_name']} added to cart."))
            # Could prompt for checkout or continue shopping
        else:
            # Option to redirect back to category selection or show more products
            return await step.replace_dialog("WFDialog")
        return await step.end_dialog()
