from botbuilder.dialogs import ComponentDialog, WaterfallDialog, WaterfallStepContext
from botbuilder.dialogs.prompts import TextPrompt, PromptOptions
from botbuilder.core import MessageFactory

from dialogs.ecommerce_dialog import EcommerceDialog

class RootDialog(ComponentDialog):
    def __init__(self, dialog_id: str = "RootDialog"):
        super(RootDialog, self).__init__(dialog_id)

        # Add all the prompts that will be used by the dialog
        self.add_dialog(TextPrompt(TextPrompt.__name__))
        
        # Define the main dialog and its related steps
        self.add_dialog(WaterfallDialog("WFDialog", [
            self.prompt_for_action,
            self.dispatch_to_intent
        ]))
        
        # Add the EcommerceDialog to this root dialog
        self.add_dialog(EcommerceDialog(EcommerceDialog.__name__))

        self.initial_dialog_id = "WFDialog"

    async def prompt_for_action(self, step_context: WaterfallStepContext):
        # Prompt the user to specify what they want to do
        return await step_context.prompt(
            TextPrompt.__name__,
            PromptOptions(prompt=MessageFactory.text("Welcome! Are you here to browse products, check on an order, or need help with something else?"))
        )

    async def dispatch_to_intent(self, step_context: WaterfallStepContext):
        # Dispatch the user to the appropriate dialog based on their response
        response = step_context.result.lower()
        if 'browse' in response or 'products' in response or 'shop' in response:
            return await step_context.begin_dialog(EcommerceDialog.__name__)
        elif 'order' in response:
            # Here you would have another dialog for order checking if it exists
            pass
        elif 'help' in response:
            # Here you could have a help dialog
            pass
        else:
            await step_context.context.send_activity("I'm sorry, I don't understand. Let's try again.")
            return await step_context.replace_dialog(self.id)

        return await step_context.end_dialog()
