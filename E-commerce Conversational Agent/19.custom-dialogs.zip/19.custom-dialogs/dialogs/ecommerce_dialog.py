from botbuilder.dialogs import ComponentDialog, WaterfallDialog, WaterfallStepContext
from botbuilder.dialogs.prompts import TextPrompt, ChoicePrompt, PromptOptions
from botbuilder.core import MessageFactory
from botbuilder.dialogs.choices import Choice

# Mock data for sneakers, replace this with a call to your product service
SNEAKERS_DATA = [
    {'name': 'Nike Air Max', 'brand': 'Nike', 'color': 'Black', 'size': '9', 'price': '120'},
    {'name': 'Adidas Ultraboost', 'brand': 'Adidas', 'color': 'White', 'size': '9', 'price': '180'},
    {'name': 'Puma Ignite', 'brand': 'Puma', 'color': 'Red', 'size': '9', 'price': '100'},
]

class EcommerceDialog(ComponentDialog):
    def __init__(self, dialog_id: str = "EcommerceDialog"):
        super(EcommerceDialog, self).__init__(dialog_id)

        self.add_dialog(ChoicePrompt(ChoicePrompt.__name__))
        self.add_dialog(TextPrompt(TextPrompt.__name__))

        self.add_dialog(WaterfallDialog("WFDialog", [
            self.prompt_for_category,
            self.show_products,
            self.add_to_cart,
            self.prompt_for_checkout,
            self.complete_purchase
        ]))

        self.initial_dialog_id = "WFDialog"

    async def prompt_for_category(self, step_context: WaterfallStepContext):
        categories = ["Running", "Casual", "Basketball"]
        return await step_context.prompt(
            ChoicePrompt.__name__,
            PromptOptions(
                prompt=MessageFactory.text("Which category are you interested in?"),
                choices=[Choice(category) for category in categories]
            ),
        )

    async def show_products(self, step_context: WaterfallStepContext):
        # Filter products by category
        category = step_context.result.value
        filtered_products = [product for product in SNEAKERS_DATA if category.lower() in product['name'].lower()]

        # Show products to the user
        product_choices = [Choice(product["name"]) for product in filtered_products]
        return await step_context.prompt(
            ChoicePrompt.__name__,
            PromptOptions(
                prompt=MessageFactory.text("Please choose a product for more details:"),
                choices=product_choices
            )
        )

    async def add_to_cart(self, step_context: WaterfallStepContext):
        selected_product = step_context.result.value
        # Here you would handle adding the product to the user's cart
        await step_context.context.send_activity(MessageFactory.text(f"{selected_product} added to your cart."))
        return await step_context.prompt(
            ChoicePrompt.__name__,
            PromptOptions(
                prompt=MessageFactory.text("Would you like to continue shopping or proceed to checkout?"),
                choices=[Choice("Continue Shopping"), Choice("Proceed to Checkout")]
            ),
        )

    async def prompt_for_checkout(self, step_context: WaterfallStepContext):
        response = step_context.result.value
        if response == "Proceed to Checkout":
            # Here you would handle the checkout process
            await step_context.context.send_activity(MessageFactory.text("Proceeding to checkout."))
        else:
            # If the user wants to continue shopping, you could restart the dialog or handle as needed
            await step_context.context.send_activity(MessageFactory.text("Continuing shopping."))
        
        # For simplicity, ending the dialog here, but in a real-world scenario you would continue the checkout process
        return await step_context.end_dialog()

    async def complete_purchase(self, step_context: WaterfallStepContext):
        # Finalize the purchase
        await step_context.context.send_activity(MessageFactory.text("Thank you for your purchase."))
        return await step_context.end_dialog()
